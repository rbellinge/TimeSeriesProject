function [paaseries] = paa(inputArg1,frames)
    %paa: iterates through original dataset, summing valuesalong the way,
    % stops every k frames to take the average of the past k values,
    %adding it to the array to be returned. then converts that array to a
    %piecewise function with the same domain as the original data to
    %represent the data graphically.
    length = size(inputArg1);
    framelength = length(2)/frames;
    graphfl = (length(2)-1)/frames;
    indy = 1;
    paaseries = zeros(1,frames);
    summer = 0;
    for j = 1:length(2)
        summer = summer + inputArg1(j);
        if mod(j,framelength) == 0
            paaseries(indy) = summer/framelength;
            indy = indy+1;
            summer = 0;
        end
    end
%     plot(inputArg1,'k')
%     hold on;
%     for i= 1:size(paaseries,2)
%        syms x;
%        fplot(piecewise((x > (i-1)*graphfl+1) & (x<i*graphfl+1),paaseries(i)),'r');
%     end
%     hold off;
end