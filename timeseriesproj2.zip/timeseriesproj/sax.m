function [saxseries] = sax(ts,frames)
%sax creates sax representation
%   time series normalized with mean zero standard deviation 1, does the
%   same mean calculation performed in the paa function, depending on what
%   sextile data the mean value falls in a corresponding letter is assgned.
%   sextile cutoffs were determined using z table values for 1/6,1/3,etc.
%   Each letter added to a character array to be returned.
%   to graphically represent this sax representation, each letter converted
%   to a representative double in the middle of each domain, and made into
%   a piecewise function.
    normts = normalize(ts);
    length = size(normts);
    framelength = length(2)/frames;
    graphfl = (length(2)-1)/frames;
    indy = 0;
    saxseries = char.empty;
    summer = 0;
    for j = 1:length(2)
        summer = summer + normts(j);
        if mod(j,framelength) == 0
            normseg = summer/framelength;
            indy = indy+1;
            summer = 0;
            if normseg < -.97
                saxseries(indy) = 'a';
            elseif normseg < -.43
                saxseries(indy) = 'b';
            elseif normseg < 0
                saxseries(indy) = 'c';
            elseif normseg < .43
                saxseries(indy) = 'd';
            elseif normseg < .97
                saxseries(indy) = 'e';
            else
                saxseries(indy) = 'f';
            end
        end
    end
%     plotsax = double.empty;
%     for i= 1:size(saxseries,2)
%         letter = saxseries(i);
%         switch letter
%             case 'a'
%                 plotsax(i) =-1.38;
%             case 'b'
%                 plotsax(i) = -.68;
%             case 'c'
%                 plotsax(i) = -.21;
%             case 'd'
%                 plotsax(i) = .21;
%             case 'e'
%                 plotsax(i) = .68;
%             case 'f'
%                 plotsax(i) = 1.38;
%         end
%     end
%     plot(normts,'k')
%     hold on;
%     for i= 1:size(plotsax,2)
%         syms x;
%         fplot(piecewise((x > (i-1)*graphfl+1) & (x<i*graphfl+1),plotsax(i)),'r');
%     end
%     hold off
end