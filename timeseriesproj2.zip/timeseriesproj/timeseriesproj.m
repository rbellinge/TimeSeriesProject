colclass = int8.empty;
class = 1;
%creating the label column
for i = 1:600
    colclass(i,:) = class;
    if mod(i,100) == 0
        class = class+1;
    end
end
colclasstable = array2table(colclass,'VariableNames',{'Class'});
%converting synthetic controls to paa and sax representations
paaArray = double.empty;
saxArray = char.empty;
synth = table2array(synthetic_control);
for i = 1:600
    paaArray(i,:) = paa(synth(i,:),12);
    saxArray(i,:) = sax(synth(i,:),12);
end
paaTable = array2table(paaArray);
%splitting data into training and test sets
testtrainsplit = cvpartition(600,'Holdout',.25);
synthtrain = synthetic_control(training(testtrainsplit),:);
synthtest = synthetic_control(test(testtrainsplit),:);
classtrain = colclasstable(training(testtrainsplit),:);
classtest = colclasstable(test(testtrainsplit),:);
paatrain = paaTable(training(testtrainsplit),:);
paatest = paaTable(test(testtrainsplit),:);
%fitting the models
%modelfull = fitcknn(synthtrain,classtrain,'Distance','cityblock','NumNeighbors',10);
modelfull = fitcknn(synthtrain,classtrain,'Distance','euclidean','NumNeighbors',10);
kmodelfull = crossval(modelfull,'KFold',8);
modelpaa = fitcknn(paatrain,classtrain,'Distance','cityblock','NumNeighbors',10);
%modelpaa = fitcknn(paatrain,classtrain,'Distance','euclidean','NumNeighbors',10);
kmodelpaa = crossval(modelpaa,'KFold',8);
%generating predictions on the test data
guessesfull = predict(modelfull,synthtest);
guessespaa = predict(modelpaa,paatest);
labelarray = table2array(classtest);
%evaluating results
C = confusionmat(labelarray,guessespaa);
confusionchart(C);